#include "rclcpp/rclcpp.hpp"
#include "division_rclcpp/srv/divide.hpp"

class DivisionService : public rclcpp::Node 
{
public:
    DivisionService() : Node("division_service") 
    {
        service_ = this->create_service<division_rclcpp::srv::Divide>(
            "divide",
            std::bind(&DivisionService::handle_divide, this, std::placeholders::_1, std::placeholders::_2));
        RCLCPP_INFO(this->get_logger(), "Ready to divide.");
    }

private:
    void handle_divide(const std::shared_ptr<division_rclcpp::srv::Divide::Request> request,
                       std::shared_ptr<division_rclcpp::srv::Divide::Response> response) 
    {
        if (request->divisor == 0) {
            RCLCPP_ERROR(this->get_logger(), "Divisor is zero.");
            response->quotient = 0;
            response->remainder = 0;
            return; // 返回错误
        }
        response->quotient = request->dividend / request->divisor;
        response->remainder = request->dividend % request->divisor;
    }

    rclcpp::Service<division_rclcpp::srv::Divide>::SharedPtr service_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<DivisionService>());
    rclcpp::shutdown();
    return 0;
}
