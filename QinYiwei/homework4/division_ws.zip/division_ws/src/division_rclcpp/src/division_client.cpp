#include "rclcpp/rclcpp.hpp"
#include "division_rclcpp/division_rclcpp/srv/divide.hpp"

class DivisionClient : public rclcpp::Node 
{
public:
    DivisionClient() : Node("division_client") 
    {
        client_ = this->create_client<division_rclcpp::srv::Divide>("divide");
    }

    void send_request(int dividend, int divisor) 
    {
        auto request = std::make_shared<division_rclcpp::srv::Divide::Request>();
        request->dividend = dividend;
        request->divisor = divisor;

        while (!client_->wait_for_service(std::chrono::seconds(1))) 
        {
            if (!rclcpp::ok()) 
            {
                RCLCPP_ERROR(this->get_logger(), "Interrupted while waiting for the service. Exiting.");
                return;
            }
            RCLCPP_INFO(this->get_logger(), "Waiting for service to be available...");
        }

        auto result = client_->async_send_request(request);
        if (rclcpp::spin_until_future_complete(this->get_node_base_interface(), result) ==
            rclcpp::executor::FutureReturnCode::SUCCESS) 
        {
            RCLCPP_INFO(this->get_logger(), "Quotient: %d, Remainder: %d", result.get()->quotient, result.get()->remainder);
        } else 
        {
            RCLCPP_ERROR(this->get_logger(), "Failed to call service divide");
        }
    }

private:
    rclcpp::Client<division_rclcpp::srv::Divide>::SharedPtr client_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);

    if (argc != 3) {
        RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Usage: division_client <dividend> <divisor>");
        return 1;
    }

    DivisionClient client;
    client.send_request(std::atoi(argv[1]), std::atoi(argv[2]));

    rclcpp::shutdown();
    return 0;
}
