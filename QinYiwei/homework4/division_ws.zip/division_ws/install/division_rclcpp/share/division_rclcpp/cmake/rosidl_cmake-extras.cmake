# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(division_rclcpp_IDL_FILES "srv/Divide.idl")
set(division_rclcpp_INTERFACE_FILES "srv/Divide.srv;srv/Divide_Request.msg;srv/Divide_Response.msg")
