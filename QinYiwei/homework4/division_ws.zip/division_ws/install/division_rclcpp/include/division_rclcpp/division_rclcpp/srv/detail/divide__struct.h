// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from division_rclcpp:srv/Divide.idl
// generated code does not contain a copyright notice

#ifndef DIVISION_RCLCPP__SRV__DETAIL__DIVIDE__STRUCT_H_
#define DIVISION_RCLCPP__SRV__DETAIL__DIVIDE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/Divide in the package division_rclcpp.
typedef struct division_rclcpp__srv__Divide_Request
{
  int32_t dividend;
  int32_t divisor;
} division_rclcpp__srv__Divide_Request;

// Struct for a sequence of division_rclcpp__srv__Divide_Request.
typedef struct division_rclcpp__srv__Divide_Request__Sequence
{
  division_rclcpp__srv__Divide_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} division_rclcpp__srv__Divide_Request__Sequence;


// Constants defined in the message

/// Struct defined in srv/Divide in the package division_rclcpp.
typedef struct division_rclcpp__srv__Divide_Response
{
  int32_t quotient;
  int32_t remainder;
} division_rclcpp__srv__Divide_Response;

// Struct for a sequence of division_rclcpp__srv__Divide_Response.
typedef struct division_rclcpp__srv__Divide_Response__Sequence
{
  division_rclcpp__srv__Divide_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} division_rclcpp__srv__Divide_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DIVISION_RCLCPP__SRV__DETAIL__DIVIDE__STRUCT_H_
