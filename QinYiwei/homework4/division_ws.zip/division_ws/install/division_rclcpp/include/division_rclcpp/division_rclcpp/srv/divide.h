// generated from rosidl_generator_c/resource/idl.h.em
// with input from division_rclcpp:srv/Divide.idl
// generated code does not contain a copyright notice

#ifndef DIVISION_RCLCPP__SRV__DIVIDE_H_
#define DIVISION_RCLCPP__SRV__DIVIDE_H_

#include "division_rclcpp/srv/detail/divide__struct.h"
#include "division_rclcpp/srv/detail/divide__functions.h"
#include "division_rclcpp/srv/detail/divide__type_support.h"

#endif  // DIVISION_RCLCPP__SRV__DIVIDE_H_
