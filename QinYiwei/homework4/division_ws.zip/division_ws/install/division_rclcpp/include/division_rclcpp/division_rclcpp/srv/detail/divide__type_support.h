// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from division_rclcpp:srv/Divide.idl
// generated code does not contain a copyright notice

#ifndef DIVISION_RCLCPP__SRV__DETAIL__DIVIDE__TYPE_SUPPORT_H_
#define DIVISION_RCLCPP__SRV__DETAIL__DIVIDE__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "division_rclcpp/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_division_rclcpp
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  division_rclcpp,
  srv,
  Divide_Request
)();

// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_division_rclcpp
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  division_rclcpp,
  srv,
  Divide_Response
)();

#include "rosidl_runtime_c/service_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_division_rclcpp
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_c,
  division_rclcpp,
  srv,
  Divide
)();

#ifdef __cplusplus
}
#endif

#endif  // DIVISION_RCLCPP__SRV__DETAIL__DIVIDE__TYPE_SUPPORT_H_
