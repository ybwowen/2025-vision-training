// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from division_rclcpp:srv/Divide.idl
// generated code does not contain a copyright notice

#ifndef DIVISION_RCLCPP__SRV__DETAIL__DIVIDE__BUILDER_HPP_
#define DIVISION_RCLCPP__SRV__DETAIL__DIVIDE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "division_rclcpp/srv/detail/divide__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace division_rclcpp
{

namespace srv
{

namespace builder
{

class Init_Divide_Request_divisor
{
public:
  explicit Init_Divide_Request_divisor(::division_rclcpp::srv::Divide_Request & msg)
  : msg_(msg)
  {}
  ::division_rclcpp::srv::Divide_Request divisor(::division_rclcpp::srv::Divide_Request::_divisor_type arg)
  {
    msg_.divisor = std::move(arg);
    return std::move(msg_);
  }

private:
  ::division_rclcpp::srv::Divide_Request msg_;
};

class Init_Divide_Request_dividend
{
public:
  Init_Divide_Request_dividend()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Divide_Request_divisor dividend(::division_rclcpp::srv::Divide_Request::_dividend_type arg)
  {
    msg_.dividend = std::move(arg);
    return Init_Divide_Request_divisor(msg_);
  }

private:
  ::division_rclcpp::srv::Divide_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::division_rclcpp::srv::Divide_Request>()
{
  return division_rclcpp::srv::builder::Init_Divide_Request_dividend();
}

}  // namespace division_rclcpp


namespace division_rclcpp
{

namespace srv
{

namespace builder
{

class Init_Divide_Response_remainder
{
public:
  explicit Init_Divide_Response_remainder(::division_rclcpp::srv::Divide_Response & msg)
  : msg_(msg)
  {}
  ::division_rclcpp::srv::Divide_Response remainder(::division_rclcpp::srv::Divide_Response::_remainder_type arg)
  {
    msg_.remainder = std::move(arg);
    return std::move(msg_);
  }

private:
  ::division_rclcpp::srv::Divide_Response msg_;
};

class Init_Divide_Response_quotient
{
public:
  Init_Divide_Response_quotient()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Divide_Response_remainder quotient(::division_rclcpp::srv::Divide_Response::_quotient_type arg)
  {
    msg_.quotient = std::move(arg);
    return Init_Divide_Response_remainder(msg_);
  }

private:
  ::division_rclcpp::srv::Divide_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::division_rclcpp::srv::Divide_Response>()
{
  return division_rclcpp::srv::builder::Init_Divide_Response_quotient();
}

}  // namespace division_rclcpp

#endif  // DIVISION_RCLCPP__SRV__DETAIL__DIVIDE__BUILDER_HPP_
