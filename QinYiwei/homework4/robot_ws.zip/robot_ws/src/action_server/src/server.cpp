#include "rclcpp/rclcpp.hpp"
#include "action_interfaces/srv/move_distance.hpp"

class ActionServer : public rclcpp::Node {
public:
    ActionServer() : Node("action_server") {
        this->declare_parameter<double>("v", 0.5);
        this->declare_parameter<double>("time_limit", 5.0);
        service_ = this->create_service<action_interfaces::srv::MoveDistance>(
            "move_distance",
            std::bind(&ActionServer::handle_request, this, std::placeholders::_1, std::placeholders::_2));
    }

private:
    rclcpp::Service<action_interfaces::srv::MoveDistance>::SharedPtr service_;

    void handle_request(const std::shared_ptr<action_interfaces::srv::MoveDistance::Request> request,
                        std::shared_ptr<action_interfaces::srv::MoveDistance::Response> response) {
        double distance = request->distance;
        double v = this->get_parameter("v").as_double();
        double time_limit = this->get_parameter("time_limit").as_double();

        double remaining_distance = distance;
        auto start_time = this->get_clock()->now();

        while (remaining_distance > 0) {
            auto elapsed_time = this->get_clock()->now() - start_time;
            if (elapsed_time.seconds() > time_limit) {
                response->success = false;
                remaining_distance /= 2;
                break;
            }

            remaining_distance -= v; 
            response->remaining_distance = remaining_distance;
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        if (remaining_distance <= 0) {
            response->success = true;
        }
    }
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<ActionServer>());
    rclcpp::shutdown();
    return 0;
}
