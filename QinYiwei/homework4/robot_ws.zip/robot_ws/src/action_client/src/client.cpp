#include "rclcpp/rclcpp.hpp"
#include "action_interfaces/srv/move_distance.hpp"

class ActionClient : public rclcpp::Node {
public:
    ActionClient() : Node("action_client") {
        client_ = this->create_client<action_interfaces::srv::MoveDistance>("move_distance");
        this->declare_parameter<double>("initial_distance", 10.0);
    }

    void send_request() {
        double distance = this->get_parameter("initial_distance").as_double();
        while (distance > 0) {
            auto request = std::make_shared<action_interfaces::srv::MoveDistance::Request>();
            request->distance = distance;

            while (!client_->wait_for_service(std::chrono::seconds(1))) {
                if (!rclcpp::ok()) {
                    RCLCPP_ERROR(this->get_logger(), "Interrupted while waiting for the service. Exiting.");
                    return;
                }
                RCLCPP_INFO(this->get_logger(), "Waiting for service...");
            }

            auto future = client_->async_send_request(request);
            if (rclcpp::spin_until_future_complete(this->get_node_base_interface(), future) ==
                    rclcpp::FutureReturnCode::SUCCESS) {

                auto response = future.get();
                if (response->success) {
                    RCLCPP_INFO(this->get_logger(), "Action succeeded!");
                    break;
                } else {
                    RCLCPP_WARN(this->get_logger(), "Action failed, trying again with half distance.");
                    distance /= 2;
                }
            } else {
                RCLCPP_ERROR(this->get_logger(), "Failed to call service");
                break;
            }
        }
    }

private:
    rclcpp::Client<action_interfaces::srv::MoveDistance>::SharedPtr client_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<ActionClient>();
    node->send_request();
    rclcpp::shutdown();
    return 0;
}
