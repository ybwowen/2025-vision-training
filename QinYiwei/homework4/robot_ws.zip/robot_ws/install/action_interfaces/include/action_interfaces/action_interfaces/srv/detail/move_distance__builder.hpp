// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from action_interfaces:srv/MoveDistance.idl
// generated code does not contain a copyright notice

#ifndef ACTION_INTERFACES__SRV__DETAIL__MOVE_DISTANCE__BUILDER_HPP_
#define ACTION_INTERFACES__SRV__DETAIL__MOVE_DISTANCE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "action_interfaces/srv/detail/move_distance__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace action_interfaces
{

namespace srv
{

namespace builder
{

class Init_MoveDistance_Request_distance
{
public:
  Init_MoveDistance_Request_distance()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::action_interfaces::srv::MoveDistance_Request distance(::action_interfaces::srv::MoveDistance_Request::_distance_type arg)
  {
    msg_.distance = std::move(arg);
    return std::move(msg_);
  }

private:
  ::action_interfaces::srv::MoveDistance_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::action_interfaces::srv::MoveDistance_Request>()
{
  return action_interfaces::srv::builder::Init_MoveDistance_Request_distance();
}

}  // namespace action_interfaces


namespace action_interfaces
{

namespace srv
{

namespace builder
{

class Init_MoveDistance_Response_remaining_distance
{
public:
  explicit Init_MoveDistance_Response_remaining_distance(::action_interfaces::srv::MoveDistance_Response & msg)
  : msg_(msg)
  {}
  ::action_interfaces::srv::MoveDistance_Response remaining_distance(::action_interfaces::srv::MoveDistance_Response::_remaining_distance_type arg)
  {
    msg_.remaining_distance = std::move(arg);
    return std::move(msg_);
  }

private:
  ::action_interfaces::srv::MoveDistance_Response msg_;
};

class Init_MoveDistance_Response_success
{
public:
  Init_MoveDistance_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveDistance_Response_remaining_distance success(::action_interfaces::srv::MoveDistance_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_MoveDistance_Response_remaining_distance(msg_);
  }

private:
  ::action_interfaces::srv::MoveDistance_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::action_interfaces::srv::MoveDistance_Response>()
{
  return action_interfaces::srv::builder::Init_MoveDistance_Response_success();
}

}  // namespace action_interfaces

#endif  // ACTION_INTERFACES__SRV__DETAIL__MOVE_DISTANCE__BUILDER_HPP_
