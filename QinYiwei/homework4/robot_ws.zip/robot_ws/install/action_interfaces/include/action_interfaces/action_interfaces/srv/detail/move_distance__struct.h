// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from action_interfaces:srv/MoveDistance.idl
// generated code does not contain a copyright notice

#ifndef ACTION_INTERFACES__SRV__DETAIL__MOVE_DISTANCE__STRUCT_H_
#define ACTION_INTERFACES__SRV__DETAIL__MOVE_DISTANCE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/MoveDistance in the package action_interfaces.
typedef struct action_interfaces__srv__MoveDistance_Request
{
  double distance;
} action_interfaces__srv__MoveDistance_Request;

// Struct for a sequence of action_interfaces__srv__MoveDistance_Request.
typedef struct action_interfaces__srv__MoveDistance_Request__Sequence
{
  action_interfaces__srv__MoveDistance_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} action_interfaces__srv__MoveDistance_Request__Sequence;


// Constants defined in the message

/// Struct defined in srv/MoveDistance in the package action_interfaces.
typedef struct action_interfaces__srv__MoveDistance_Response
{
  bool success;
  double remaining_distance;
} action_interfaces__srv__MoveDistance_Response;

// Struct for a sequence of action_interfaces__srv__MoveDistance_Response.
typedef struct action_interfaces__srv__MoveDistance_Response__Sequence
{
  action_interfaces__srv__MoveDistance_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} action_interfaces__srv__MoveDistance_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ACTION_INTERFACES__SRV__DETAIL__MOVE_DISTANCE__STRUCT_H_
