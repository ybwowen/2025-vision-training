from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('param_file', default_value='config/params.yaml'),

        Node(
            package='action_server',
            executable='server',
            name='action_server',
            parameters=[LaunchConfiguration('param_file')]
        ),

        Node(
            package='action_client',
            executable='client',
            name='action_client',
            parameters=[LaunchConfiguration('param_file')]
        ),
    ])
